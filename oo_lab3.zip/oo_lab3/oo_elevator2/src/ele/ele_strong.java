package ele;

interface ele_strong {
	 double reset();
	 int asknowpos();
	 double answer_request(int floor);
	
}
